var Jake, jake_running;

var bomb;

var coin;

var energyDrink;

var path;

function preload(){
  //pre-load images
  jake_running.loadImage("Jake1.png,Jake2.png,Jake3.png,Jake4.png,Jake5.png");
 
  
  
}

function setup(){
  createCanvas(400,400);
  //create sprites here
  Jake = createSprite(200,400);
  Jake.addAnimation("running");
}

function draw() {
  background("white");
drawSprite();
}
